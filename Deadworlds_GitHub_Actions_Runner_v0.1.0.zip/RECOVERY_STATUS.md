# Deadworlds Science Runner v0.8.9 — Recovery / Promotion Status

Snapshot: 2026-10-28

## Exact-grid reconstruction — PASS

The reconstructed exact-grid path remains regression-locked to the authoritative six-phase v0.7 reference, including the 3-fold transition partition `0,1,2,0,1`.

## Genuine PyMC 6 runtime and exact-grid parity — PASS

Validated runtime:
- Python 3.13.18
- PyMC 6.3.2
- PyTensor 3.3.4
- ArviZ 1.1.0
- NumPy 2.1.3

The predeclared PyMC-vs-exact-grid parity policy passed, and the returned NetCDF SHA-256 matched independently.

## SBC v1 — FAIL, preserved

Policy: `deadworlds-pymc-cultural-sbc-v1`

The 200-simulation calibration behavior itself passed:
- rank ECDF: PASS
- rank mean: PASS
- rank variance: PASS
- 50/80/90% interval coverage: PASS
- failed simulations: 0
- divergences: 0

The frozen gate failed only the short-run sampler-diagnostic fractions:
- R-hat <= 1.01: 0.815 (required 0.99)
- bulk ESS >= 200: 0.93 (required 0.99)
- tail ESS >= 200: 0.895 (required 0.99)

This result is not overwritten or reclassified. Full v1 rows/report and a failure audit are retained in `historical/sbc_v1/`.

## SBC v2 — FROZEN, PENDING

Policy: `deadworlds-pymc-cultural-sbc-v2-sampling-depth`

This is a diagnostic-resolution rerun, not a threshold rewrite.

Unchanged:
- same 200 deterministic simulated datasets
- same prior `Uniform(-0.6, 0.6)`
- same fixed source-count conditioning design
- same generative seed scheme
- same rank/coverage definitions
- same promotion tolerances
- same scientific interpretation ceiling

Changed only:
- PyMC sampling from 2 chains × 500 draws + 500 tune
- to 4 chains × 1000 draws + 1000 tune

The purpose is to determine whether the v1 failures were caused by insufficient MCMC depth. No sandbox plugin registration is permitted unless v2 passes unchanged.

## Promotion boundary

If SBC v2 passes unchanged:
1. patch **sandbox only** to register the PyMC cultural plugin and its server-controlled parameters;
2. issue a synthetic Worker-generated PyMC job;
3. execute the real resumable Google Drive upload;
4. submit through Forge;
5. require sanitizer + private storage verification;
6. require paired persistence to remain `ANALYTICAL_RESULT_ONLY`;
7. clean temporary rows/artifacts;
8. re-audit production/sandbox gameplay/canon/artifact tables for zero contamination.

Production remains untouched.

## v0.8.9 Colab execution hardening

The scientific SBC v2 policy is unchanged from v0.8.5. This revision changes execution ergonomics only:

- `PYMC6_SBC_ROWS.json` is now a real resumable checkpoint rather than write-only progress.
- Checkpoint rows are seed-validated against the frozen deterministic policy before reuse.
- A failed/incomplete final row is retried with the same seeds; successful prefix rows are never silently regenerated.
- Progress is printed before and after every simulation with `flush=True`.
- `--max-new N` supports bounded notebook batches without changing the 200-simulation design.
- `KeyboardInterrupt` preserves completed rows and explicitly reports that rerunning resumes.

No SBC threshold, prior, dataset seed, model likelihood, chain/draw/tune count, or scientific interpretation changed.


## Sandbox Worker → PyMC → Drive → Forge E2E — PASS (2026-10-28)

The sandbox synthetic Cultural Transmission PyMC job completed through the real capability lease, private compute-storage Worker, Google Drive resumable upload, Drive SHA-256 verification, Forge sanitizer, job-package binding validation, and sandbox completion state. Production compute/model-comparison tables remained zero.

Observed E2E diagnostics: 4 chains × 1000 draws, 0 divergences, rhat_max=1.0033014509100115, ess_bulk_min=1617.9835919935429, ess_tail_min=1840.2043579038987. ELPD=-26.96537112286203. The result satisfies the frozen exact-grid parity policy.

The v0.8.6 archive had a provenance-label defect: `pyproject.toml` said 0.8.6 while `deadworlds_compute.__version__` still said 0.8.4, causing the raw result to identify runner version 0.8.4. The raw result is preserved unchanged as audit evidence. v0.8.9 corrects the internal version and adds a regression test requiring package/version consistency. No scientific likelihood, prior, partition, SBC policy, or transport contract changed.

During sandbox E2E setup, a direct API Worker upload temporarily dropped non-secret sandbox bindings. The exact previous binding set and compatibility date were recovered from Cloudflare version history and restored. Future Forge deployments require explicit post-deploy binding verification in addition to `/health`.


## Sandbox paired analytical persistence — PASS

The real `maybePersistCompletedPairedComparison` D1 path was exercised with the authoritative neutral exact result and the actual sandbox PyMC E2E frequency result. It persisted `ANALYTICAL_RESULT_ONLY`, delta ELPD (frequency minus neutral) 3.093382484444227, SE 3.240167565863443, 2-SE interval [-3.3869526472826585, 9.573717616171113], and status `MODEL_INDISTINGUISHABLE_AT_CURRENT_VALIDATION_RESOLUTION`. `preferredModel` and `modelTruthProbabilities` remained null. The synthetic compute/comparison rows were then deleted.

The E2E Drive artifact was deleted and independently checked through the private compute-storage `list-analysis` path; zero files remained for the synthetic analysis. Final sandbox counts: sandbox compute jobs 0, forge compute jobs 0, forge model comparisons 0. Production compute/model-comparison counts remained 0/0.

Sandbox Forge regression v1.95 now makes `/health` fail if any required binding is missing. The health binding contract covers AI, AI_ROUTER, COMPUTE_STORAGE, DB, DEADWORLDS_ADMIN_SECRET, FORGE_MODEL, and SANDBOX_CONTROL_TOKEN.


## v0.8.9 promotion delta

- Runner capability transport now uses `X-Deadworlds-Capability`, matching the successful sandbox Worker → Drive → Forge E2E path.
- Exact-grid remains the preferred/default production backend for the current one-parameter closed-state cultural model.
- PyMC is eligible for explicit backend selection after parity, 200-simulation SBC, and real Drive/Forge E2E validation; this does not imply model truth.


## v0.8.9 packaging correction

The v0.8.8 source metadata required `xarray>=2026.1`, while the validated PyMC environment used xarray 2025.12.0. v0.8.9 corrects the compatible range and adds `PRODUCTION_CONSTRAINTS.txt` with the exact validated scientific stack. No likelihood, inference, transport, or scientific-contract logic changed.
