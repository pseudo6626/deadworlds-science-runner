# One-time GitHub setup

1. Create a repository named `deadworlds-science-runner` under GitHub user `pseudo6626`.
2. Make it **Public**. The repository contains no credentials or private Deadworlds evidence; public standard GitHub-hosted Actions avoid private-repository compute billing.
3. Do not add a README/license/gitignore when creating it; ChatGPT will populate the audited tree afterward.
4. Create a fine-grained personal access token for Forge dispatch:
   - Repository access: only `pseudo6626/deadworlds-science-runner`
   - Repository permission required for repository dispatch: **Contents: Read and write**
   - Give it a sensible expiration.
5. Put that token into the existing Cloudflare Secrets Store as `GITHUB_DEADWORLDS_DISPATCH_TOKEN`. Do not paste the token into chat.
6. Return to ChatGPT. It will:
   - populate the repo,
   - add/validate the GitHub OIDC claim endpoint in sandbox,
   - run a real sandbox GitHub-hosted E2E,
   - wire Forge `repository_dispatch`,
   - promote only after the E2E passes,
   - preserve zero-contamination cleanup.

No GitHub secret is stored in the repository.
