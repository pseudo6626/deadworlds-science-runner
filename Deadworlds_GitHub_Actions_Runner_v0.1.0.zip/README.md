# Deadworlds Science Runner

Free/local scientific-compute runner for the Deadworlds Evidence Forge / Module 15 compute contract.

## Current recovery version

`0.8.7`

This is a **forward reconstruction** from the authoritative live Forge contracts and preserved scientific reference results after the original runner `0.7.0` package became unavailable. It is not a byte-for-byte recreation of `0.7.0` and must never be assigned the old package SHA.

## Validation state

Validated:

- exact neutral Cultural Transmission plugin `cultural_neutral_copying_v1`;
- exact-grid frequency-dependent plugin `cultural_frequency_dependent_grid_v1`;
- authoritative six-phase fixture and 3-fold phase-transition partition;
- stored pointwise predictive densities, ELPDs, SEs, and beta posterior summaries to numerical precision;
- zero-to-positive closed-state appearances fail closed;
- plugin/model/inference/artifact-format and Worker-issued provenance bindings fail closed;
- resumable Google Drive transport contract via local mock E2E;
- **genuine PyMC 6.3.2 / PyTensor 3.3.4 / ArviZ 1.1.0 doctor: PASS**;
- **PyMC-vs-exact-grid parity: PASS** under the predeclared `deadworlds-pymc-cultural-parity-v1` tolerances;
- returned NetCDF SHA-256 independently verified;
- exact-grid sanity check of the predeclared SBC design: PASS;
- local deterministic regression suite: 7/7 PASS.

Still pending:

- genuine PyMC 6 simulation-based calibration (SBC) under `SBC_POLICY.json`;
- Worker-issued sandbox PyMC E2E;
- real Drive upload + Forge sanitizer + paired analytical persistence.

`pymc_cultural_frequency_dependent_v1` remains **experimental and unregistered in Forge** until those gates pass.

## Scientific model

For destination counts and source sample frequencies `p_i`, the closed-state frequency-dependent model uses:

`q_i ∝ p_i^(1 - beta)`

Therefore:

- `beta < 0`: common-variant / conformity-like bias;
- `beta = 0`: neutral copying;
- `beta > 0`: rare-variant / anti-conformity-like bias.

These are model-conditional parameter semantics only. Predictive preference is not historical truth, cognition, contact, or population prevalence.

Closed-state rules preserved here:

- one independently coded trait family per job;
- validation units are ordered phase transitions;
- recovered frequencies are sample frequencies;
- zero-to-positive state appearances are blocked unless an explicit innovation model exists;
- PPCs are restricted to predeclared discrepancies;
- raw runner output contains no winner/preferred-model/truth-probability field.

## Authoritative six-phase reference

Fixture counts:

- P0: A=50, B=30, C=20
- P1: A=55, B=29, C=16
- P2: A=60, B=27, C=13
- P3: A=59, B=28, C=13
- P4: A=72, B=17, C=11
- P5: A=81, B=14, C=5

Transition folds: `0,1,2,0,1` for P0->P1 through P4->P5.

The fixture-specific exact grid is `[-0.6, 0.6]` with 1201 points. That is intentionally distinct from the current production materializer default `[-0.5, 0.5]` with 1001 points.

## PyMC 6 parity result

The external validation result ZIP passed the frozen parity policy:

- ELPD absolute difference: `0.01686733162055276` (limit `0.20`)
- worst pointwise absolute difference: `0.007349425344707505` (limit `0.12`)
- beta mean absolute difference: `1.4399059136027681e-05` (limit `0.02`)
- beta SD absolute difference: `0.0027587907846370885` (limit `0.02`)
- worst beta quantile absolute difference: `0.006288282844556903` (limit `0.03`)
- divergences: `0`
- R-hat max: `1.0035946528909832`
- bulk ESS min: `1661.3001107886257`
- tail ESS min: `1725.1456801050317`

See `PYMC6_PARITY_AUDIT.json`.

This is an implementation-parity result only. It is not evidence that the cultural model is empirically adequate or historically true.

## SBC gate

`SBC_POLICY.json` was frozen **before any PyMC SBC output was observed**. The SBC gate uses 200 prior-predictive simulations of the scalar beta parameter under `Uniform(-0.6, 0.6)`.

The source-count rows from the six-phase synthetic fixture are held fixed as conditioning covariates, and destination counts are simulated from the same multinomial frequency-bias likelihood used by the PyMC plugin. This intentionally validates the conditional inference implementation rather than inventing a generative archaeological history model.

The frozen SBC checks include:

- posterior-rank ECDF DKW bound;
- posterior-rank mean and variance calibration;
- 50%, 80%, and 90% posterior interval coverage;
- failed-run count;
- total divergences;
- per-run R-hat pass fraction;
- per-run bulk/tail ESS pass fractions.

The exact-grid sanity check of this SBC design is recorded in `EXACT_SBC_PRECHECK_REPORT.json` and passes. That is **not** the PyMC SBC result.

In a genuine PyMC 6 environment run:

```bash
python examples/run_pymc6_sbc.py
```

Expected outputs:

- `PYMC6_SBC_DOCTOR_REPORT.json`
- `PYMC6_SBC_REPORT.json`
- `PYMC6_SBC_ROWS.json`
- `PYMC6_SBC_NUMERIC.npz`

## Local tests

```bash
python -m pip install -e '.[dev]'
pytest -q
```

Current package result: `7 passed`.

## Runtime

Recommended clean environment:

- Python 3.12+
- PyMC 6.x
- PyTensor 3.x
- ArviZ 1.x / arviz-stats 1.x
- NumPy 2.x
- xarray + h5netcdf + h5py

Run the hard runtime gate before any PyMC scientific test:

```bash
deadworlds-compute doctor
```

## Transport flow

For an actual Worker-issued bundle containing capabilities:

1. execute the issued model job;
2. hash the full draw artifact locally;
3. request a one-job Google Drive resumable-upload lease from Forge;
4. upload in resumable chunks;
5. require Drive's returned SHA-256 and byte size to match locally;
6. submit compact diagnostics + provenance + `gdrive://<file-id>`;
7. Forge independently asks the private storage Worker to verify SHA-256, size, MIME, parent folder, and job-binding appProperties before accepting completion.

Full posterior draws remain outside D1.

## Safety boundary

This runner performs scientific computation only. It does not mutate canon or decide which historical explanation is true. Forge remains authoritative for model eligibility, plugin registration, server-controlled parameters, artifact validation, paired analytical persistence, and all science firewalls.


## SBC v2 sampling-depth rerun

The first genuine PyMC 6 SBC run preserved calibration but failed the frozen R-hat/ESS passing-fraction thresholds under 2 chains × 500 posterior draws. v0.8.9 does **not** relax those thresholds. It reruns the same deterministic 200 simulated datasets with 4 chains × 1000 posterior draws and 1000 tuning steps per chain. The full v1 report and rows are retained under `historical/sbc_v1/`.

## Colab SBC v2 resume behavior (v0.8.9)

The SBC v2 scientific policy is unchanged. The Colab runner now streams one simulation at a time and treats `PYMC6_SBC_ROWS.json` as a validated resumable checkpoint. If a Colab cell is interrupted, rerun the SBC cell; successful completed simulations are retained and the interrupted simulation is retried with the same frozen seeds. The notebook also attempts to migrate a same-runtime v0.8.5 checkpoint automatically.


## v0.8.9 transport promotion

Capability-authenticated lease and result submission use the dedicated `X-Deadworlds-Capability` header. The token semantics and SHA-256 storage contract are unchanged. The Forge may retain Bearer authorization as a backwards-compatible server fallback, but the runner does not send the generic `Authorization` header.


## Reproducible production environment

`PRODUCTION_CONSTRAINTS.txt` pins the exact PyMC 6 runtime that passed parity, the 200-simulation SBC gate, and the real Drive/Forge E2E. The project metadata permits compatible future patch/minor dependency versions, but production installation should prefer the constraints file until a newer stack is revalidated.
