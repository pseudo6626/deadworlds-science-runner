# Deadworlds Science Runner — GitHub Actions

This repository is the ephemeral scientific-compute runner for Deadworlds.

## Security model

The repository intentionally contains no Deadworlds secrets.

Forge triggers `repository_dispatch` with only a random compute-job UUID. The workflow requests a short-lived GitHub OIDC token with audience `deadworlds-compute`. Forge verifies the OIDC signature and claims, then mints fresh one-job lease/submission capabilities and returns the immutable Worker-issued bundle.

The workflow never discovers jobs, never sees hidden canon/generator truth, and never receives Google credentials. NetCDF/NPZ artifacts are uploaded through the existing private compute-storage broker to Google Drive.

## Scientific ceiling

Passing a compute job means the declared inference implementation ran successfully. Fit is not truth; model preference is not unique historical truth; similarity is not contact/copying/common descent.

## Expected repository identity

`pseudo6626/deadworlds-science-runner`

The production Forge OIDC trust policy should accept only:
- issuer `https://token.actions.githubusercontent.com`
- audience `deadworlds-compute`
- repository `pseudo6626/deadworlds-science-runner`
- event `repository_dispatch`
- workflow on the default branch at `.github/workflows/deadworlds-compute.yml`

## No GitHub secrets required

The Actions workflow needs only:
- `contents: read`
- `id-token: write`

A separate fine-grained GitHub token is required on the **Cloudflare side only** so Forge can create `repository_dispatch` events. Limit it to this repository and the minimum repository permission GitHub requires for repository dispatch.

## Runtime

The runner source is Deadworlds Science Runner v0.8.9. `PRODUCTION_CONSTRAINTS.txt` pins the exact PyMC stack already validated by parity, SBC, and real Drive/Forge E2E.
