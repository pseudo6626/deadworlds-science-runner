from __future__ import annotations

import math
from pathlib import Path

from deadworlds_compute.contracts import ComputeJob, JOB_SOURCE_RULE, JOB_VERSION, sha256_json
from deadworlds_compute.runner import execute


REFERENCE_ROWS = [
    ("P0", {"A": 50, "B": 30, "C": 20}),
    ("P1", {"A": 55, "B": 29, "C": 16}),
    ("P2", {"A": 60, "B": 27, "C": 13}),
    ("P3", {"A": 59, "B": 28, "C": 13}),
    ("P4", {"A": 72, "B": 17, "C": 11}),
    ("P5", {"A": 81, "B": 14, "C": 5}),
]
PARTITION = {
    "scheme": "K_FOLD_TRANSITIONS_V1",
    "fold_count": 3,
    "assignments": {"P0->P1": 0, "P1->P2": 1, "P2->P3": 2, "P3->P4": 0, "P4->P5": 1},
}


def make_job(plugin: str, model_id: str, parameters: dict):
    input_data = {
        "trait_family": "synthetic_motif_class",
        "observation_unit": "find",
        "phase_order": [p for p, _ in REFERENCE_ROWS],
        "phase_counts": [{"phase_id": p, "counts": c, "sample_size": sum(c.values())} for p, c in REFERENCE_ROWS],
        "validation_partition": PARTITION,
        "source_semantics": "coded recovered-record frequency; not population prevalence",
    }
    plan = {
        "validation_unit_status": "DEFINED_AND_JUSTIFIED",
        "dependence_structure_status": "MODELED_OR_RESPECTED",
        "predeclared_discrepancies": ["mean_interphase_tv_distance", "mean_destination_shannon_entropy"],
        "heldout_or_cv_partition_status": "AVAILABLE",
        "sbc_status": "NOT_RUN",
        "prior_predictive_status": "NOT_RUN",
        "abc_summary_discrimination_status": "PARTIAL_STRONG_EFFECT_DISCRIMINATION_ONLY",
        "predictive_validation_method": "K_FOLD",
        "inference_method": "FIXED_PREDICTIVE" if plugin == "cultural_neutral_copying_v1" else "GRID_BAYES",
        "evaluation_scope": "MODEL_ADEQUACY_AND_VALIDATED_RELATIVE_COMPARISON",
        "observed_variable": "phase_counts",
        "partition_sha256": sha256_json(PARTITION),
    }
    manifest = {
        "job_version": JOB_VERSION,
        "analysis_id": f"ct-synthetic-001-{model_id}",
        "comparison_group_id": "ct:synthetic_motif_class",
        "candidate_model_id": model_id,
        "source_module": "cultural_transmission",
        "source_version": "deadworlds-cultural-transmission-v1.0.0",
        "random_seed": 20261028,
        "model": {"plugin": plugin, "parameters": parameters},
        "input_data": input_data,
        "evaluation_plan": plan,
        "artifact_format": "JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT",
    }
    expected = {
        "job_manifest_sha256": sha256_json(manifest),
        "input_sha256": sha256_json(input_data),
        "model_spec_sha256": sha256_json(manifest["model"]),
        "evaluation_plan_sha256": sha256_json(plan),
    }
    return ComputeJob({"package_version": JOB_VERSION, "sourceRule": JOB_SOURCE_RULE, "manifest": manifest, "expected_hashes": expected})


def test_authoritative_neutral_reference(tmp_path: Path):
    job = make_job("cultural_neutral_copying_v1", "neutral_unbiased_copying", {"chains": 4, "draws": 1000})
    result = execute(job, tmp_path / "neutral")
    pv = result["predictive_validation"]
    assert math.isclose(pv["elpd"], -30.058753607306258, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(pv["se"], 3.4083257738659394, rel_tol=0, abs_tol=1e-12)
    expected = [-5.306281821307621, -5.114887034346822, -4.559275828774986, -8.318798334823626, -6.759510588053203]
    got = [x["log_predictive_density"] for x in pv["pointwise"]]
    assert all(math.isclose(a, b, rel_tol=0, abs_tol=1e-12) for a, b in zip(got, expected))


def test_authoritative_frequency_grid_reference(tmp_path: Path):
    # The historical six-phase validation fixture explicitly issued [-0.6, 0.6] / 1201,
    # distinct from the current production materializer defaults [-0.5, 0.5] / 1001.
    job = make_job(
        "cultural_frequency_dependent_grid_v1",
        "frequency_dependent_alternative",
        {"chains": 4, "draws": 1000, "b_prior_min": -0.6, "b_prior_max": 0.6, "grid_points": 1201},
    )
    result = execute(job, tmp_path / "frequency")
    pv = result["predictive_validation"]
    assert math.isclose(pv["elpd"], -26.951595127178244, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(pv["se"], 2.080280160238995, rel_tol=0, abs_tol=1e-12)
    expected = [-4.783394954338751, -4.660451258352586, -6.192741545044889, -6.599398441653179, -4.715608927788838]
    got = [x["log_predictive_density"] for x in pv["pointwise"]]
    assert all(math.isclose(a, b, rel_tol=0, abs_tol=1e-12) for a, b in zip(got, expected))
    s = result["parameter_summaries"][0]
    assert math.isclose(s["mean"], -0.2588764747792396, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(s["sd"], 0.08899470883037511, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(s["q05"], -0.40732080106531254, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(s["q50"], -0.2585178468863979, rel_tol=0, abs_tol=1e-12)
    assert math.isclose(s["q95"], -0.11443666893163834, rel_tol=0, abs_tol=1e-12)


def test_zero_to_positive_appearance_fails_closed(tmp_path: Path):
    job = make_job("cultural_neutral_copying_v1", "neutral_unbiased_copying", {"chains": 4, "draws": 100})
    job.raw["manifest"]["input_data"]["phase_counts"][0]["counts"].pop("C")
    job.raw["manifest"]["input_data"]["phase_counts"][0]["sample_size"] = 80
    try:
        execute(job, tmp_path / "blocked")
    except ValueError as exc:
        assert "zero-to-positive" in str(exc).lower()
    else:
        raise AssertionError("closed-state zero-to-positive appearance was not blocked")
