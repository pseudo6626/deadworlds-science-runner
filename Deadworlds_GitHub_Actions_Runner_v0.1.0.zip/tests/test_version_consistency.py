from pathlib import Path
import re
import deadworlds_compute


def test_package_version_matches_pyproject():
    root = Path(__file__).resolve().parents[1]
    text = (root / "pyproject.toml").read_text(encoding="utf-8")
    m = re.search(r'^version\s*=\s*"([^"]+)"', text, flags=re.MULTILINE)
    assert m, "pyproject project version not found"
    assert deadworlds_compute.__version__ == m.group(1)
