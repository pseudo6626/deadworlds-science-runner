from pathlib import Path

def test_github_claim_script_has_no_static_capabilities():
    text = Path("scripts/claim_bundle.py").read_text(encoding="utf-8")
    assert "lease_token" in text
    assert "submission" in text
    assert "GITHUB_DEADWORLDS_DISPATCH_TOKEN" not in text
    assert "GOOGLE_" not in text

def test_workflow_uses_oidc_and_repository_dispatch():
    text = Path(".github/workflows/deadworlds-compute.yml").read_text(encoding="utf-8")
    assert "repository_dispatch" in text
    assert "id-token: write" in text
    assert "audience=deadworlds-compute" in text
    assert "WORKER_BUNDLE.json" in text
