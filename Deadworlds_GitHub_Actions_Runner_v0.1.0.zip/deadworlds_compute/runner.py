from __future__ import annotations

import importlib.metadata
import json
import platform
from pathlib import Path
from typing import Any

from . import __version__
from .contracts import ComputeJob, RESULT_SOURCE_RULE, RESULT_VERSION, sha256_file
from .plugins.cultural_exact import CulturalFrequencyDependentGridPlugin, CulturalNeutralCopyingPlugin
from .plugins.gaussian_exact import GaussianLocationExactPlugin
from .plugins.pymc_cultural import PyMCCulturalFrequencyDependentPlugin
from .plugins.pymc_gaussian import PyMCGaussianLocationPlugin
from .transport import TransportCapability, store_artifact_via_capability

PLUGINS = {
    GaussianLocationExactPlugin.name: GaussianLocationExactPlugin(),
    PyMCGaussianLocationPlugin.name: PyMCGaussianLocationPlugin(),
    CulturalNeutralCopyingPlugin.name: CulturalNeutralCopyingPlugin(),
    CulturalFrequencyDependentGridPlugin.name: CulturalFrequencyDependentGridPlugin(),
    PyMCCulturalFrequencyDependentPlugin.name: PyMCCulturalFrequencyDependentPlugin(),
}

# Local runner safety map. Forge remains authoritative for what is registered server-side.
PLUGIN_CONTRACTS = {
    "gaussian_location_exact": {"artifact": "JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT", "inference": {"AUTO", "SIMULATION_ONLY"}},
    "pymc_gaussian_location": {"artifact": "ARVIZ_INFERENCE_DATA_NETCDF", "inference": {"AUTO", "MCMC"}},
    "cultural_neutral_copying_v1": {"model": "neutral_unbiased_copying", "artifact": "JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT", "inference": {"FIXED_PREDICTIVE"}},
    "cultural_frequency_dependent_grid_v1": {"model": "frequency_dependent_alternative", "artifact": "JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT", "inference": {"GRID_BAYES"}},
    # Experimental only. Current Forge does NOT register this plugin; local validation is
    # allowed, but Worker-issued E2E must wait for the PyMC 6 gate and sandbox promotion.
    "pymc_cultural_frequency_dependent_v1": {"model": "frequency_dependent_alternative", "artifact": "ARVIZ_INFERENCE_DATA_NETCDF", "inference": {"MCMC"}},
}


def _version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _validate_runner_plugin_binding(job: ComputeJob) -> None:
    contract = PLUGIN_CONTRACTS.get(job.plugin)
    if contract is None:
        raise ValueError(f"No local runner contract is defined for plugin {job.plugin!r}")
    expected_model = contract.get("model")
    if expected_model is not None and job.model_id != expected_model:
        raise ValueError(f"Plugin/model mismatch: {job.plugin} cannot execute candidate {job.model_id}")
    issued_format = str(job.manifest.get("artifact_format") or "")
    if issued_format != contract["artifact"]:
        raise ValueError(
            f"Worker-issued artifact format mismatch for {job.plugin}: "
            f"expected {contract['artifact']}, got {issued_format or '<missing>'}"
        )
    issued_inference = str(job.evaluation_plan.get("inference_method") or "AUTO").upper()
    if issued_inference not in contract["inference"]:
        raise ValueError(
            f"Worker-issued inference method mismatch for {job.plugin}: "
            f"{issued_inference} not in {sorted(contract['inference'])}"
        )


def execute(
    job: ComputeJob,
    output_dir: str | Path,
    *,
    transport: TransportCapability | None = None,
) -> dict[str, Any]:
    plugin = PLUGINS.get(job.plugin)
    if plugin is None:
        raise ValueError(f"Unsupported model plugin: {job.plugin}. Available: {sorted(PLUGINS)}")
    _validate_runner_plugin_binding(job)

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run = plugin.run(job, out_dir)
    if run.artifact_format != job.manifest.get("artifact_format"):
        raise ValueError(
            f"Plugin returned artifact format {run.artifact_format}, but Worker issued {job.manifest.get('artifact_format')}"
        )

    artifact_hash = sha256_file(run.draw_artifact)
    artifact_ref = run.draw_artifact.resolve().as_uri()
    storage_receipt = None

    if transport is not None:
        artifact_mime = {
            ".nc": "application/x-netcdf",
            ".npz": "application/octet-stream",
            ".zip": "application/zip",
        }.get(run.draw_artifact.suffix.lower(), "application/octet-stream")
        receipt = store_artifact_via_capability(
            transport,
            job,
            run.draw_artifact,
            artifact_sha256=artifact_hash,
            mime_type=artifact_mime,
        )
        artifact_ref = receipt.artifact_ref
        storage_receipt = {
            "provider": "google_drive",
            "file_id": receipt.file_id,
            "name": receipt.name,
            "mime_type": receipt.mime_type,
            "size": receipt.size,
            "sha256": receipt.sha256,
            "md5": receipt.md5,
            "web_view_link": receipt.web_view_link,
        }

    # These hashes are the exact Worker-issued provenance values. They are echoed unchanged
    # rather than regenerated when constructing the result artifact.
    expected = job.expected_hashes
    libraries = {
        "python": platform.python_version(),
        "numpy": _version("numpy") or "unknown",
        "arviz": _version("arviz") or "unknown",
        "xarray": _version("xarray") or "unknown",
    }
    if job.plugin.startswith("pymc_"):
        for lib in ("pymc", "pytensor", "h5netcdf", "h5py"):
            if (v := _version(lib)) is not None:
                libraries[lib] = v

    result = {
        "artifactVersion": RESULT_VERSION,
        "sourceRule": RESULT_SOURCE_RULE,
        "analysis_id": job.analysis_id,
        "comparison_group_id": job.group_id,
        "candidate_model_id": job.model_id,
        "job_manifest_sha256": expected["job_manifest_sha256"],
        "input_sha256": expected["input_sha256"],
        "model_spec_sha256": expected["model_spec_sha256"],
        "evaluation_plan_sha256": expected["evaluation_plan_sha256"],
        "random_seed": job.random_seed,
        "runner": {"name": "deadworlds-science-runner", "version": __version__, "libraries": libraries},
        "artifact_ref": artifact_ref,
        "artifact_sha256": artifact_hash,
        "artifact_format": run.artifact_format,
        "sampler_diagnostics": run.sampler_diagnostics,
        "posterior_predictive_checks": run.posterior_predictive_checks,
        "predictive_validation": run.predictive_validation,
        "parameter_summaries": run.parameter_summaries,
        "sbc": run.sbc,
    }
    if storage_receipt is not None:
        result["storage_receipt"] = storage_receipt
        result["transport"] = {
            "provider": "GOOGLE_DRIVE_RESUMABLE",
            "file_id": storage_receipt["file_id"],
            "file_name": storage_receipt["name"],
            "mime_type": storage_receipt["mime_type"],
            "size_bytes": storage_receipt["size"],
            "md5_checksum": storage_receipt["md5"],
            "sha256_checksum": storage_receipt["sha256"],
        }

    # No winner/preferred/truth-probability fields are emitted by the runner.
    result_path = out_dir / f"{job.analysis_id}__{job.model_id}__result.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    result["_result_path"] = str(result_path)
    return result
