from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from ..contracts import ComputeJob
from .base import PluginRun
from .cultural_common import (
    elpd_se,
    logsumexp,
    multinomial_logpmf,
    parse_closed_state_input,
    ppc_rows,
    transition_probabilities,
)


def _posterior_values(idata: Any, name: str) -> np.ndarray:
    if hasattr(idata, "children") and "posterior" in idata.children:
        return np.asarray(idata["posterior"].dataset[name].values, dtype=float)
    if hasattr(idata, "posterior"):
        return np.asarray(idata.posterior[name].values, dtype=float)
    raise TypeError(f"Unsupported PyMC/ArviZ posterior container: {type(idata)!r}")


def _sample_stats_values(idata: Any, name: str) -> np.ndarray | None:
    if hasattr(idata, "children") and "sample_stats" in idata.children:
        ds = idata["sample_stats"].dataset
        return np.asarray(ds[name].values) if name in ds else None
    if hasattr(idata, "sample_stats") and name in idata.sample_stats:
        return np.asarray(idata.sample_stats[name].values)
    return None


def _diagnostic_values(tree: Any, variable: str) -> np.ndarray:
    if hasattr(tree, "children") and "posterior" in tree.children:
        return np.asarray(tree["posterior"].dataset[variable].values, dtype=float)
    if hasattr(tree, "dataset") and variable in tree.dataset:
        return np.asarray(tree.dataset[variable].values, dtype=float)
    if hasattr(tree, "data_vars") and variable in tree:
        return np.asarray(tree[variable].values, dtype=float)
    raise TypeError(f"Unsupported ArviZ diagnostic container: {type(tree)!r}")


def _fit_beta(
    source: np.ndarray,
    destination: np.ndarray,
    *,
    b_min: float,
    b_max: float,
    chains: int,
    draws: int,
    tune: int,
    seed: int,
):
    import pymc as pm
    import pytensor.tensor as pt

    source_p = np.asarray(source, dtype=float)
    source_p = source_p / source_p.sum(axis=1, keepdims=True)
    dest = np.asarray(destination, dtype=np.int64)
    n = dest.sum(axis=1).astype("int64")
    coords = {"transition": np.arange(dest.shape[0]), "state": np.arange(dest.shape[1])}
    with pm.Model(coords=coords) as model:
        beta = pm.Uniform("beta", lower=b_min, upper=b_max)
        src = pt.as_tensor_variable(source_p)
        weights = pt.pow(src, 1.0 - beta)
        q = weights / pt.sum(weights, axis=1, keepdims=True)
        pm.Multinomial("destination_counts", n=n, p=q, observed=dest, dims=("transition", "state"))
        idata = pm.sample(
            draws=draws,
            tune=tune,
            chains=chains,
            random_seed=seed,
            progressbar=False,
            quiet=True,
            cores=1,
            nuts_sampler="pymc",
            return_inferencedata=True,
        )
    return model, idata


class PyMCCulturalFrequencyDependentPlugin:
    """PyMC 6 MCMC implementation of the exact closed-state frequency-bias likelihood.

    This plugin intentionally matches the exact-grid reference model rather than the older
    latent Dirichlet-diffusion experiment. It remains experimental/unregistered in Forge
    until a genuine PyMC 6 runtime, synthetic Worker-issued E2E, Drive upload, sanitizer,
    paired persistence, and zero-contamination audit all pass.
    """

    name = "pymc_cultural_frequency_dependent_v1"

    def run(self, job: ComputeJob, output_dir: Path) -> PluginRun:
        import arviz as az
        import arviz_stats as azs
        import pymc as pm

        major = int(str(pm.__version__).split(".")[0])
        if major != 6:
            raise RuntimeError(f"{self.name} requires PyMC 6.x; found PyMC {pm.__version__}")
        az_major = int(str(az.__version__).split(".")[0])
        if az_major != 1:
            raise RuntimeError(f"{self.name} requires ArviZ 1.x; found ArviZ {az.__version__}")
        if str(job.evaluation_plan.get("predictive_validation_method") or "").upper() != "K_FOLD":
            raise ValueError(f"{self.name} requires K_FOLD predictive validation")

        data = parse_closed_state_input(job.input_data)
        p = job.parameters
        chains = int(p.get("chains", 4))
        draws = int(p.get("draws", 1000))
        tune = int(p.get("tune", 1000))
        b_min = float(p.get("b_prior_min", -0.5))
        b_max = float(p.get("b_prior_max", 0.5))
        if chains <= 0 or draws <= 0 or tune < 0 or not b_min < b_max:
            raise ValueError("invalid PyMC Cultural Transmission sampling parameters")

        source = np.asarray(data.counts[:-1], dtype=float)
        destination = np.asarray(data.counts[1:], dtype=np.int64)
        full_model, idata = _fit_beta(
            source,
            destination,
            b_min=b_min,
            b_max=b_max,
            chains=chains,
            draws=draws,
            tune=tune,
            seed=job.random_seed,
        )
        beta_full = _posterior_values(idata, "beta").reshape(-1)

        fold_ids = np.asarray(data.fold_ids)
        pointwise = np.empty(data.transition_count, dtype=float)
        for fold in sorted(set(data.fold_ids)):
            train = fold_ids != fold
            held = fold_ids == fold
            _, fold_idata = _fit_beta(
                source[train],
                destination[train],
                b_min=b_min,
                b_max=b_max,
                chains=chains,
                draws=draws,
                tune=tune,
                seed=(job.random_seed + 1009 * (fold + 1)) & 0xFFFFFFFF,
            )
            beta_fold = _posterior_values(fold_idata, "beta").reshape(-1)
            for idx in np.flatnonzero(held):
                lp = np.asarray(
                    [
                        multinomial_logpmf(destination[idx], transition_probabilities(source[idx], float(beta)))
                        for beta in beta_fold
                    ],
                    dtype=float,
                )
                pointwise[idx] = logsumexp(lp) - np.log(lp.size)

        # Posterior predictive diagnostics use the full-data posterior and the same forward
        # simulator as the exact-grid plugin. This avoids introducing a second discrepancy
        # definition merely because the inference engine changed.
        rng = np.random.default_rng(job.random_seed)
        ppc = ppc_rows(
            data,
            beta_full,
            rng,
            set(job.evaluation_plan.get("predeclared_discrepancies") or []),
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        draw_path = output_dir / f"{job.analysis_id}__{job.model_id}__idata.nc"
        idata.to_netcdf(draw_path)

        rhat = azs.rhat(idata, var_names=["beta"])
        ess_bulk = azs.ess(idata, var_names=["beta"], method="bulk")
        ess_tail = azs.ess(idata, var_names=["beta"], method="tail")
        div = _sample_stats_values(idata, "diverging")
        try:
            _, diagnose = azs.diagnose(idata, return_diagnostics=True, show_diagnostics=False)
            bfmi_values = np.asarray(diagnose.get("bfmi", {}).get("bfmi_values", []), dtype=float)
            bfmi_min = float(np.min(bfmi_values)) if bfmi_values.size else None
        except Exception:
            bfmi_min = None
        q = np.quantile(beta_full, [0.05, 0.50, 0.95])
        summary = {
            "parameter_id": "frequency_bias_beta",
            "mean": float(np.mean(beta_full)),
            "sd": float(np.std(beta_full, ddof=1)),
            "q05": float(q[0]),
            "q50": float(q[1]),
            "q95": float(q[2]),
            "unit": "dimensionless",
            "semantics": "MODEL_CONDITIONAL_PARAMETER_SUMMARY_ONLY",
        }
        validation = {
            "method": "K_FOLD",
            "elpd": float(pointwise.sum()),
            "se": elpd_se(pointwise),
            "pointwise_log_likelihood_available": True,
            "partition_sha256": job.evaluation_plan.get("partition_sha256"),
            "pointwise": [
                {"unit_id": tid, "log_predictive_density": float(lp)}
                for tid, lp in zip(data.transition_ids, pointwise)
            ],
        }
        return PluginRun(
            draw_artifact=draw_path,
            artifact_format="ARVIZ_INFERENCE_DATA_NETCDF",
            sampler_diagnostics={
                "inference_class": "MCMC",
                "chains": chains,
                "draws_per_chain": draws,
                "divergences": int(np.asarray(div).sum()) if div is not None else None,
                "rhat_max": float(np.max(_diagnostic_values(rhat, "beta"))),
                "ess_bulk_min": float(np.min(_diagnostic_values(ess_bulk, "beta"))),
                "ess_tail_min": float(np.min(_diagnostic_values(ess_tail, "beta"))),
                "bfmi_min": bfmi_min,
            },
            posterior_predictive_checks=ppc,
            predictive_validation=validation,
            parameter_summaries=[summary],
            sbc={"status": "NOT_RUN", "simulations": 0, "rank_diagnostics": []},
        )
