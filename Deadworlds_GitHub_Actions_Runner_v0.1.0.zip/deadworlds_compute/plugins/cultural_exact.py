from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from ..contracts import ComputeJob
from .base import PluginRun
from .cultural_common import (
    elpd_se,
    logsumexp,
    normalize_logweights,
    parse_closed_state_input,
    ppc_rows,
    transition_loglikelihoods,
    weighted_grid_summary,
)


class CulturalNeutralCopyingPlugin:
    name = "cultural_neutral_copying_v1"

    def run(self, job: ComputeJob, output_dir: Path) -> PluginRun:
        if str(job.evaluation_plan.get("predictive_validation_method") or "").upper() != "K_FOLD":
            raise ValueError("cultural_neutral_copying_v1 requires K_FOLD predictive validation")
        data = parse_closed_state_input(job.input_data)
        pointwise = transition_loglikelihoods(data, beta=0.0)
        p = job.parameters
        chains = int(p.get("chains", 4))
        draws = int(p.get("draws", 1000))
        if chains <= 0 or draws <= 0:
            raise ValueError("chains/draws must be positive")

        rng = np.random.default_rng(job.random_seed)
        beta_draws = np.zeros(chains * draws, dtype=float)
        ppc = ppc_rows(
            data,
            beta_draws,
            rng,
            set(job.evaluation_plan.get("predeclared_discrepancies") or []),
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        draw_path = output_dir / f"{job.analysis_id}__{job.model_id}__closed_state_draws.npz"
        np.savez_compressed(
            draw_path,
            beta=beta_draws.reshape(chains, draws),
            pointwise_log_predictive_density=pointwise,
            transition_ids=np.asarray(data.transition_ids),
            fold_ids=np.asarray(data.fold_ids),
            phase_counts=data.counts,
            states=np.asarray(data.states),
        )
        validation = {
            "method": "K_FOLD",
            "elpd": float(pointwise.sum()),
            "se": elpd_se(pointwise),
            "pointwise_log_likelihood_available": True,
            "partition_sha256": job.evaluation_plan.get("partition_sha256"),
            "pointwise": [
                {"unit_id": tid, "log_predictive_density": float(lp)}
                for tid, lp in zip(data.transition_ids, pointwise)
            ],
        }
        return PluginRun(
            draw_artifact=draw_path,
            artifact_format="JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT",
            sampler_diagnostics={
                "inference_class": "FIXED_PREDICTIVE",
                "chains": chains,
                "draws_per_chain": draws,
                "divergences": 0,
                "rhat_max": None,
                "ess_bulk_min": None,
                "ess_tail_min": None,
                "bfmi_min": None,
            },
            posterior_predictive_checks=ppc,
            predictive_validation=validation,
            parameter_summaries=[],
            sbc={"status": "NOT_RUN", "simulations": 0, "rank_diagnostics": []},
        )


class CulturalFrequencyDependentGridPlugin:
    name = "cultural_frequency_dependent_grid_v1"

    def run(self, job: ComputeJob, output_dir: Path) -> PluginRun:
        if str(job.evaluation_plan.get("predictive_validation_method") or "").upper() != "K_FOLD":
            raise ValueError("cultural_frequency_dependent_grid_v1 requires K_FOLD predictive validation")
        data = parse_closed_state_input(job.input_data)
        p = job.parameters
        chains = int(p.get("chains", 4))
        draws = int(p.get("draws", 1000))
        b_min = float(p.get("b_prior_min", -0.5))
        b_max = float(p.get("b_prior_max", 0.5))
        grid_points = int(p.get("grid_points", 1001))
        if chains <= 0 or draws <= 0:
            raise ValueError("chains/draws must be positive")
        if not np.isfinite(b_min) or not np.isfinite(b_max) or b_min >= b_max:
            raise ValueError("invalid frequency-bias prior bounds")
        if grid_points < 101 or grid_points > 100_001:
            raise ValueError("grid_points must be between 101 and 100001")
        beta_grid = np.linspace(b_min, b_max, grid_points, dtype=float)
        loglik = np.stack([transition_loglikelihoods(data, float(beta)) for beta in beta_grid], axis=1)

        full_log_posterior = loglik.sum(axis=0)
        full_weights = normalize_logweights(full_log_posterior)
        summary = weighted_grid_summary(beta_grid, full_weights)

        pointwise = np.empty(data.transition_count, dtype=float)
        unique_folds = sorted(set(data.fold_ids))
        fold_weights: dict[int, np.ndarray] = {}
        fold_array = np.asarray(data.fold_ids)
        for fold in unique_folds:
            train = fold_array != fold
            held = fold_array == fold
            train_log_posterior = loglik[train].sum(axis=0)
            weights = normalize_logweights(train_log_posterior)
            fold_weights[fold] = weights
            logw = np.log(weights)
            for idx in np.flatnonzero(held):
                pointwise[idx] = logsumexp(logw + loglik[idx])

        rng = np.random.default_rng(job.random_seed)
        beta_draws = rng.choice(beta_grid, size=chains * draws, replace=True, p=full_weights)
        ppc = ppc_rows(
            data,
            beta_draws,
            rng,
            set(job.evaluation_plan.get("predeclared_discrepancies") or []),
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        draw_path = output_dir / f"{job.analysis_id}__{job.model_id}__grid_posterior.npz"
        artifact = {
            "beta_grid": beta_grid,
            "full_posterior_weights": full_weights,
            "beta_draws": beta_draws.reshape(chains, draws),
            "pointwise_log_predictive_density": pointwise,
            "transition_ids": np.asarray(data.transition_ids),
            "fold_ids": np.asarray(data.fold_ids),
            "phase_counts": data.counts,
            "states": np.asarray(data.states),
        }
        for fold, weights in fold_weights.items():
            artifact[f"fold_{fold}_posterior_weights"] = weights
        np.savez_compressed(draw_path, **artifact)

        validation = {
            "method": "K_FOLD",
            "elpd": float(pointwise.sum()),
            "se": elpd_se(pointwise),
            "pointwise_log_likelihood_available": True,
            "partition_sha256": job.evaluation_plan.get("partition_sha256"),
            "pointwise": [
                {"unit_id": tid, "log_predictive_density": float(lp)}
                for tid, lp in zip(data.transition_ids, pointwise)
            ],
        }
        parameter_summaries: list[dict[str, Any]] = [
            {
                "parameter_id": "frequency_bias_beta",
                "mean": summary["mean"],
                "sd": summary["sd"],
                "q05": summary["q05"],
                "q50": summary["q50"],
                "q95": summary["q95"],
                "unit": "dimensionless",
                "semantics": "MODEL_CONDITIONAL_PARAMETER_SUMMARY_ONLY",
            }
        ]
        return PluginRun(
            draw_artifact=draw_path,
            artifact_format="JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT",
            sampler_diagnostics={
                "inference_class": "GRID_BAYES",
                "chains": chains,
                "draws_per_chain": draws,
                "divergences": 0,
                "rhat_max": None,
                "ess_bulk_min": None,
                "ess_tail_min": None,
                "bfmi_min": None,
            },
            posterior_predictive_checks=ppc,
            predictive_validation=validation,
            parameter_summaries=parameter_summaries,
            sbc={"status": "NOT_RUN", "simulations": 0, "rank_diagnostics": []},
        )
