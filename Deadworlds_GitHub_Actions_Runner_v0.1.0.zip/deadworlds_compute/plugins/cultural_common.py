from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class CulturalClosedStateData:
    states: tuple[str, ...]
    phase_ids: tuple[str, ...]
    counts: np.ndarray
    fold_ids: tuple[int, ...]
    transition_ids: tuple[str, ...]

    @property
    def transition_count(self) -> int:
        return len(self.transition_ids)


def _positive_int(value: Any, *, field: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{field} must be a positive integer")
    try:
        n = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a positive integer") from exc
    if n <= 0 or n != value:
        raise ValueError(f"{field} must be a positive integer")
    return n


def parse_closed_state_input(input_data: dict[str, Any]) -> CulturalClosedStateData:
    phase_order = input_data.get("phase_order")
    phase_counts = input_data.get("phase_counts")
    partition = input_data.get("validation_partition")
    if not isinstance(phase_order, list) or len(phase_order) < 4:
        raise ValueError("Cultural closed-state compute requires at least four ordered phases")
    if not isinstance(phase_counts, list) or len(phase_counts) != len(phase_order):
        raise ValueError("phase_counts must align one-to-one with phase_order")
    if not isinstance(partition, dict) or partition.get("scheme") != "K_FOLD_TRANSITIONS_V1":
        raise ValueError("Cultural closed-state compute requires K_FOLD_TRANSITIONS_V1")

    row_by_phase: dict[str, dict[str, Any]] = {}
    states: set[str] = set()
    for row in phase_counts:
        if not isinstance(row, dict):
            raise ValueError("phase_counts rows must be objects")
        pid = str(row.get("phase_id") or "").strip()
        if not pid or pid in row_by_phase:
            raise ValueError("phase_count phase_id values must be unique and non-empty")
        raw_counts = row.get("counts")
        if not isinstance(raw_counts, dict) or not raw_counts:
            raise ValueError(f"phase {pid} requires a non-empty counts object")
        clean: dict[str, int] = {}
        for state, value in raw_counts.items():
            key = str(state).strip()
            if not key:
                raise ValueError("trait-state names must be non-empty")
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"count for {pid}/{key} must be a non-negative integer")
            clean[key] = value
            states.add(key)
        sample_size = _positive_int(row.get("sample_size"), field=f"sample_size[{pid}]")
        if sum(clean.values()) != sample_size:
            raise ValueError(f"phase {pid} counts do not sum to sample_size")
        row_by_phase[pid] = {"counts": clean, "sample_size": sample_size}

    phase_ids = tuple(str(x).strip() for x in phase_order)
    if any(not x for x in phase_ids) or len(set(phase_ids)) != len(phase_ids):
        raise ValueError("phase_order must contain unique non-empty phase ids")
    if set(phase_ids) != set(row_by_phase):
        raise ValueError("phase_order and phase_counts phase ids differ")

    ordered_states = tuple(sorted(states))
    if len(ordered_states) < 2:
        raise ValueError("Cultural closed-state compute requires at least two observed states")
    matrix = np.asarray(
        [[row_by_phase[pid]["counts"].get(state, 0) for state in ordered_states] for pid in phase_ids],
        dtype=np.int64,
    )

    transition_ids = tuple(f"{phase_ids[i]}->{phase_ids[i+1]}" for i in range(len(phase_ids)-1))
    for i, tid in enumerate(transition_ids):
        src, dst = matrix[i], matrix[i+1]
        appearing = [ordered_states[j] for j in range(len(ordered_states)) if src[j] == 0 and dst[j] > 0]
        if appearing:
            raise ValueError(
                "Unmodeled zero-to-positive state appearance is blocked in the closed-state model: "
                f"{tid}: {', '.join(appearing)}"
            )

    assignments = partition.get("assignments")
    if not isinstance(assignments, dict):
        raise ValueError("validation_partition.assignments must be an object")
    fold_count = _positive_int(partition.get("fold_count"), field="validation_partition.fold_count")
    if fold_count < 3:
        raise ValueError("Cultural closed-state validation requires at least three folds")
    fold_ids: list[int] = []
    for tid in transition_ids:
        if tid not in assignments:
            raise ValueError(f"validation partition missing transition assignment: {tid}")
        fold = assignments[tid]
        if isinstance(fold, bool) or not isinstance(fold, int) or not 0 <= fold < fold_count:
            raise ValueError(f"invalid fold assignment for {tid}: {fold!r}")
        fold_ids.append(fold)
    if len(set(fold_ids)) < 3:
        raise ValueError("validation partition does not contain three populated folds")

    return CulturalClosedStateData(
        states=ordered_states,
        phase_ids=phase_ids,
        counts=matrix,
        fold_ids=tuple(fold_ids),
        transition_ids=transition_ids,
    )


def transition_probabilities(source_counts: np.ndarray, beta: float) -> np.ndarray:
    src = np.asarray(source_counts, dtype=float)
    if src.ndim != 1 or np.any(src < 0) or src.sum() <= 0:
        raise ValueError("source_counts must be a non-negative vector with positive total")
    if np.any(src == 0):
        # Zero states are permitted only when they remain zero in the destination. The
        # closed-state firewall is enforced before likelihood calculation.
        mask = src > 0
        weights = np.zeros_like(src, dtype=float)
        weights[mask] = np.power(src[mask] / src.sum(), 1.0 - float(beta))
    else:
        p = src / src.sum()
        weights = np.power(p, 1.0 - float(beta))
    total = weights.sum()
    if not np.isfinite(total) or total <= 0:
        raise ValueError("frequency-bias transformation produced invalid probabilities")
    return weights / total


def multinomial_logpmf(counts: np.ndarray, probabilities: np.ndarray) -> float:
    y = np.asarray(counts, dtype=np.int64)
    p = np.asarray(probabilities, dtype=float)
    if y.ndim != 1 or p.shape != y.shape or np.any(y < 0):
        raise ValueError("multinomial counts/probabilities shape mismatch")
    if np.any((p <= 0) & (y > 0)):
        return float("-inf")
    n = int(y.sum())
    value = math.lgamma(n + 1) - sum(math.lgamma(int(c) + 1) for c in y)
    nz = y > 0
    value += float(np.dot(y[nz], np.log(p[nz])))
    return float(value)


def transition_loglikelihoods(data: CulturalClosedStateData, beta: float) -> np.ndarray:
    return np.asarray(
        [
            multinomial_logpmf(data.counts[i + 1], transition_probabilities(data.counts[i], beta))
            for i in range(data.transition_count)
        ],
        dtype=float,
    )


def logsumexp(values: np.ndarray) -> float:
    a = np.asarray(values, dtype=float)
    m = float(np.max(a))
    if not np.isfinite(m):
        return m
    return m + math.log(float(np.exp(a - m).sum()))


def normalize_logweights(log_weights: np.ndarray) -> np.ndarray:
    lw = np.asarray(log_weights, dtype=float)
    return np.exp(lw - logsumexp(lw))


def elpd_se(pointwise: np.ndarray) -> float:
    x = np.asarray(pointwise, dtype=float)
    if x.size < 2:
        return 0.0
    return float(math.sqrt(x.size * float(np.var(x, ddof=1))))


def weighted_grid_summary(grid: np.ndarray, weights: np.ndarray) -> dict[str, float]:
    g = np.asarray(grid, dtype=float)
    w = np.asarray(weights, dtype=float)
    w = w / w.sum()
    mean = float(np.dot(g, w))
    sd = float(math.sqrt(float(np.dot((g - mean) ** 2, w))))
    cdf = np.cumsum(w)
    return {
        "mean": mean,
        "sd": sd,
        "q05": float(np.interp(0.05, cdf, g)),
        "q50": float(np.interp(0.50, cdf, g)),
        "q95": float(np.interp(0.95, cdf, g)),
    }


def observed_discrepancies(data: CulturalClosedStateData) -> dict[str, float]:
    tv = []
    entropy = []
    for i in range(data.transition_count):
        src = data.counts[i] / data.counts[i].sum()
        dst = data.counts[i + 1] / data.counts[i + 1].sum()
        tv.append(0.5 * float(np.abs(dst - src).sum()))
        nz = dst > 0
        entropy.append(float(-np.sum(dst[nz] * np.log(dst[nz]))))
    return {
        "mean_interphase_tv_distance": float(np.mean(tv)),
        "mean_destination_shannon_entropy": float(np.mean(entropy)),
    }


def simulated_discrepancies(data: CulturalClosedStateData, beta: float, rng: np.random.Generator) -> dict[str, float]:
    tv = []
    entropy = []
    for i in range(data.transition_count):
        src_counts = data.counts[i]
        q = transition_probabilities(src_counts, beta)
        n = int(data.counts[i + 1].sum())
        rep_counts = rng.multinomial(n, q)
        src = src_counts / src_counts.sum()
        dst = rep_counts / rep_counts.sum()
        tv.append(0.5 * float(np.abs(dst - src).sum()))
        nz = dst > 0
        entropy.append(float(-np.sum(dst[nz] * np.log(dst[nz]))))
    return {
        "mean_interphase_tv_distance": float(np.mean(tv)),
        "mean_destination_shannon_entropy": float(np.mean(entropy)),
    }


def ppc_rows(
    data: CulturalClosedStateData,
    beta_draws: np.ndarray,
    rng: np.random.Generator,
    allowed_discrepancies: set[str],
) -> list[dict[str, Any]]:
    obs = observed_discrepancies(data)
    wanted = [k for k in ("mean_interphase_tv_distance", "mean_destination_shannon_entropy") if k in allowed_discrepancies]
    if not wanted:
        return []
    draws = np.asarray(beta_draws, dtype=float).reshape(-1)
    reps = {k: [] for k in wanted}
    for beta in draws:
        d = simulated_discrepancies(data, float(beta), rng)
        for key in wanted:
            reps[key].append(d[key])
    rows: list[dict[str, Any]] = []
    for key in wanted:
        values = np.asarray(reps[key], dtype=float)
        observed = obs[key]
        lower = float(np.mean(values <= observed))
        upper = float(np.mean(values >= observed))
        rows.append(
            {
                "discrepancy_id": key,
                "observed_value": observed,
                "replicate_quantiles": {
                    "q05": float(np.quantile(values, 0.05)),
                    "q50": float(np.quantile(values, 0.50)),
                    "q95": float(np.quantile(values, 0.95)),
                },
                "tail_area": float(min(1.0, 2.0 * min(lower, upper))),
            }
        )
    return rows
