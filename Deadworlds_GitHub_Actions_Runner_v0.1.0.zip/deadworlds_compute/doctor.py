from __future__ import annotations

import importlib.metadata
import json
import platform
import tempfile
from pathlib import Path
from typing import Any


def _version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _major(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return int(value.split(".", 1)[0])
    except Exception:
        return None


def pymc6_doctor(*, execute_smoke: bool = True) -> dict[str, Any]:
    versions = {k: _version(k) for k in ("pymc", "arviz", "pytensor", "numpy", "xarray", "h5netcdf", "h5py")}
    result: dict[str, Any] = {
        "ok": False,
        "gate": "PYMC6_ARVIZ1_RUNTIME",
        "python": platform.python_version(),
        "versions": versions,
        "checks": {},
        "errors": [],
    }
    checks = result["checks"]
    checks["python_ge_3_12"] = tuple(map(int, platform.python_version_tuple()[:2])) >= (3, 12)
    checks["pymc_major_6"] = _major(versions["pymc"]) == 6
    checks["arviz_major_1"] = _major(versions["arviz"]) == 1
    checks["pytensor_major_ge_3"] = (_major(versions["pytensor"]) or 0) >= 3
    checks["netcdf_stack_present"] = bool(versions["xarray"] and versions["h5netcdf"] and versions["h5py"])
    if not all(checks.values()):
        result["errors"].append("VERSION_OR_NETCDF_GATE_FAILED")
        return result
    if not execute_smoke:
        result["ok"] = True
        return result

    try:
        import numpy as np
        import arviz_stats as azs
        import pymc as pm

        with pm.Model() as model:
            mu = pm.Normal("mu", 0.0, 1.0)
            pm.Normal("y", mu=mu, sigma=1.0, observed=np.asarray([0.1, -0.1, 0.05]))
            idata = pm.sample(
                draws=40,
                tune=40,
                chains=2,
                random_seed=20261028,
                progressbar=False,
                quiet=True,
                cores=1,
                nuts_sampler="pymc",
                return_inferencedata=True,
            )
        # PyMC 6 + ArviZ 1 uses xarray DataTree. We require the posterior child and a
        # successful NetCDF round trip because Deadworlds stores the full draw artifact.
        checks["datatree_posterior"] = hasattr(idata, "children") and "posterior" in idata.children
        rhat = azs.rhat(idata, var_names=["mu"])
        checks["arviz_diagnostics"] = rhat is not None
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "doctor.nc"
            idata.to_netcdf(path)
            checks["netcdf_write"] = path.exists() and path.stat().st_size > 0
        result["smoke"] = {
            "idata_type": type(idata).__name__,
            "posterior_child": checks["datatree_posterior"],
        }
    except Exception as exc:
        result["errors"].append(f"RUNTIME_SMOKE_FAILED: {type(exc).__name__}: {exc}")
        return result

    result["ok"] = all(checks.values())
    if not result["ok"] and not result["errors"]:
        result["errors"].append("RUNTIME_GATE_FAILED")
    return result


def format_doctor(result: dict[str, Any]) -> str:
    return json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True)
