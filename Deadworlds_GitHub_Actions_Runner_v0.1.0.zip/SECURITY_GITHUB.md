# Deadworlds GitHub compute security notes

1. Never put a Worker bundle, lease token, submit token, Google credential, or GitHub dispatch token in repository files, Actions secrets, event payloads, artifacts, or logs.
2. `repository_dispatch.client_payload` contains only the compute-job UUID.
3. GitHub OIDC authenticates the ephemeral runner back to Forge.
4. Forge rotates/mints lease and submit capabilities only after OIDC validation.
5. The workflow removes the bundle and OIDC JWT in an `always()` cleanup step.
6. GitHub-hosted runner storage is ephemeral; authoritative scientific draw artifacts remain in the existing Google Drive compute folder.
7. The external runner has no compute-job discovery API.
8. Production exact-grid remains the default when an exact backend exists. PyMC is an explicit validated backend.
