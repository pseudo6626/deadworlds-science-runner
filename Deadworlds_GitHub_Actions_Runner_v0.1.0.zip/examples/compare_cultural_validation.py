from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

REFERENCE = {
    "elpd": -26.951595127178244,
    "beta_mean": -0.2588764747792396,
    "beta_q50": -0.2585178468863979,
    "pointwise": [-4.783394954338751, -4.660451258352586, -6.192741545044889, -6.599398441653179, -4.715608927788838],
}


def main() -> int:
    p = argparse.ArgumentParser(description="Report PyMC-vs-exact-grid Cultural Transmission validation differences")
    p.add_argument("result", help="PyMC compact result JSON")
    args = p.parse_args()
    raw = json.loads(Path(args.result).read_text(encoding="utf-8"))
    pv = raw.get("predictive_validation") or {}
    summaries = raw.get("parameter_summaries") or []
    beta = next((x for x in summaries if x.get("parameter_id") == "frequency_bias_beta"), None)
    if beta is None:
        raise SystemExit("frequency_bias_beta summary missing")
    got_pw = [float(x["log_predictive_density"]) for x in pv.get("pointwise") or []]
    if len(got_pw) != 5:
        raise SystemExit(f"expected 5 pointwise transition values, got {len(got_pw)}")
    report = {
        "reference": REFERENCE,
        "observed": {
            "elpd": float(pv["elpd"]),
            "beta_mean": float(beta["mean"]),
            "beta_q50": float(beta["q50"]),
            "pointwise": got_pw,
        },
        "absolute_differences": {
            "elpd": abs(float(pv["elpd"]) - REFERENCE["elpd"]),
            "beta_mean": abs(float(beta["mean"]) - REFERENCE["beta_mean"]),
            "beta_q50": abs(float(beta["q50"]) - REFERENCE["beta_q50"]),
            "pointwise": [abs(a - b) for a, b in zip(got_pw, REFERENCE["pointwise"])],
        },
        "basic_sanity": {
            "all_finite": all(math.isfinite(x) for x in [float(pv["elpd"]), float(beta["mean"]), float(beta["q50"]), *got_pw]),
            "beta_sign_matches_reference": float(beta["mean"]) < 0,
            "five_transition_units": len(got_pw) == 5,
        },
        "note": "This tool reports differences; promotion tolerances must be declared before treating the PyMC validation as a pass.",
    }
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
