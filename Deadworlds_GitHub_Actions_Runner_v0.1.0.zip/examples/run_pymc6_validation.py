from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from deadworlds_compute.bundle import load_bundle
from deadworlds_compute.doctor import pymc6_doctor
from deadworlds_compute.runner import execute

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "pymc6-validation-output"


def main() -> int:
    doctor = pymc6_doctor(execute_smoke=True)
    (ROOT / "PYMC6_DOCTOR_REPORT.json").write_text(json.dumps(doctor, indent=2), encoding="utf-8")
    if not doctor.get("ok"):
        print(json.dumps(doctor, indent=2))
        return 3

    bundle = load_bundle(ROOT / "examples" / "cultural_frequency_pymc_validation_job.json")
    result = execute(bundle.job, OUT)
    result_path = Path(result["_result_path"])
    parity = ROOT / "PYMC6_PARITY_REPORT.json"
    proc = subprocess.run(
        [sys.executable, str(ROOT / "examples" / "validate_pymc6_parity.py"), str(result_path), "--out", str(parity)],
        check=False,
    )
    summary = {
        "doctor_ok": True,
        "parity_exit_code": proc.returncode,
        "parity_report": str(parity),
        "result_json": str(result_path),
        "draw_artifact": result.get("artifact_ref"),
        "next_gate_if_pass": "SBC_IMPLEMENTATION_VALIDATION_THEN_WORKER_ISSUED_SANDBOX_E2E",
    }
    (ROOT / "PYMC6_VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
