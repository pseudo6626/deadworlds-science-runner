from __future__ import annotations

import argparse
import gc
import json
import time
from pathlib import Path

import numpy as np

from deadworlds_compute.doctor import pymc6_doctor
from deadworlds_compute.plugins.cultural_common import transition_probabilities
from deadworlds_compute.plugins.pymc_cultural import (
    _diagnostic_values,
    _fit_beta,
    _posterior_values,
    _sample_stats_values,
)
from sbc_metrics import calibration_checks, rank_metrics

ROOT = Path(__file__).resolve().parents[1]
POLICY = json.loads((ROOT / "SBC_POLICY.json").read_text(encoding="utf-8"))
ROWS_PATH = ROOT / "PYMC6_SBC_ROWS.json"
PROGRESS_PATH = ROOT / "PYMC6_SBC_PROGRESS.json"
REPORT_PATH = ROOT / "PYMC6_SBC_REPORT.json"
NUMERIC_PATH = ROOT / "PYMC6_SBC_NUMERIC.npz"


def _write_json(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _expected_seeds(i: int, base_seed: int) -> tuple[int, int]:
    return (
        (base_seed + 65537 * (i + 1)) & 0xFFFFFFFF,
        (base_seed + 104729 * (i + 1)) & 0xFFFFFFFF,
    )


def _load_resume_rows(nsim: int, base_seed: int, reset: bool) -> list[dict]:
    if reset or not ROWS_PATH.exists():
        return []
    try:
        rows = json.loads(ROWS_PATH.read_text(encoding="utf-8"))
    except Exception:
        print("Checkpoint exists but is unreadable; refusing to guess. Use --reset to restart.", flush=True)
        raise
    if not isinstance(rows, list):
        raise RuntimeError("SBC checkpoint is not a JSON list")
    if len(rows) > nsim:
        raise RuntimeError("SBC checkpoint contains more rows than the frozen policy")

    # Only a contiguous prefix is resumable. A failed row is retried with the same frozen seeds.
    keep: list[dict] = []
    for i, row in enumerate(rows):
        if not isinstance(row, dict) or int(row.get("simulation", -1)) != i:
            raise RuntimeError(f"SBC checkpoint is not a contiguous simulation prefix at row {i}")
        g, s = _expected_seeds(i, base_seed)
        if int(row.get("generative_seed", -1)) != g or int(row.get("sampling_seed", -1)) != s:
            raise RuntimeError(f"SBC checkpoint seed mismatch at simulation {i}; refusing to mix runs")
        if row.get("status") != "PASS_RUN":
            print(f"Checkpoint row {i} was not successful; it will be rerun with the same seeds.", flush=True)
            break
        keep.append(row)
    if len(keep) != len(rows):
        _write_json(ROWS_PATH, keep)
    return keep


def _finalize(rows: list[dict], doctor: dict) -> int:
    d = POLICY["design"]
    nsim = int(d["simulations"])
    tol = POLICY["promotion_tolerances"]
    successful = [x for x in rows if x.get("status") == "PASS_RUN"]
    failed = len([x for x in rows if x.get("status") == "FAILED_RUN"])
    rank_u = [float(x["rank_u"]) for x in successful]
    covers = {
        "50": [bool(x["coverage_50"]) for x in successful],
        "80": [bool(x["coverage_80"]) for x in successful],
        "90": [bool(x["coverage_90"]) for x in successful],
    }
    if successful:
        metrics = rank_metrics(np.asarray(rank_u), {k: np.asarray(v) for k, v in covers.items()})
        checks = calibration_checks(metrics, POLICY)
        total_div = int(sum(int(x["divergences"]) for x in successful))
        rhat_fraction = float(np.mean([float(x["rhat"]) <= tol["rhat_threshold"] for x in successful]))
        bulk_fraction = float(np.mean([float(x["ess_bulk"]) >= tol["ess_bulk_threshold"] for x in successful]))
        tail_fraction = float(np.mean([float(x["ess_tail"]) >= tol["ess_tail_threshold"] for x in successful]))
    else:
        metrics = {"simulations": 0, "rank_mean": None, "rank_variance": None, "rank_ecdf_max_deviation": None, "coverage": {"50": None, "80": None, "90": None}}
        checks = {k: False for k in ("rank_ecdf_dkw_pass", "rank_mean_pass", "rank_variance_pass", "coverage_50_pass", "coverage_80_pass", "coverage_90_pass")}
        total_div = -1
        rhat_fraction = bulk_fraction = tail_fraction = 0.0

    checks.update({
        "all_frozen_simulations_complete": len(rows) == nsim and len(successful) == nsim,
        "failed_simulations_pass": failed <= tol["failed_simulations_max"],
        "total_divergences_pass": total_div >= 0 and total_div <= tol["total_divergences_max"],
        "rhat_fraction_pass": rhat_fraction >= tol["rhat_passing_fraction_min"],
        "ess_bulk_fraction_pass": bulk_fraction >= tol["ess_bulk_passing_fraction_min"],
        "ess_tail_fraction_pass": tail_fraction >= tol["ess_tail_passing_fraction_min"],
    })
    status = "PASS" if len(rows) == nsim and all(checks.values()) else "INCOMPLETE" if len(rows) < nsim else "FAIL"
    report = {
        "policy_version": POLICY["policy_version"],
        "status": status,
        "doctor": {"ok": doctor.get("ok"), "versions": doctor.get("versions")},
        "design": d,
        "metrics": metrics,
        "sampler_metrics": {
            "failed_simulations": failed,
            "total_divergences": total_div,
            "rhat_passing_fraction": rhat_fraction,
            "ess_bulk_passing_fraction": bulk_fraction,
            "ess_tail_passing_fraction": tail_fraction,
        },
        "checks": checks,
        "tolerances": tol,
        "scientific_interpretation": POLICY["interpretation"],
        "next_gate_if_pass": "WORKER_ISSUED_SANDBOX_PYMC_E2E_WITH_REAL_DRIVE_TRANSPORT",
    }
    _write_json(REPORT_PATH, report)
    _write_json(ROWS_PATH, rows)
    np.savez_compressed(
        NUMERIC_PATH,
        rank_u=np.asarray(rank_u, dtype=float),
        beta_true=np.asarray([x["beta_true"] for x in successful], dtype=float),
        rhat=np.asarray([x["rhat"] for x in successful], dtype=float),
        ess_bulk=np.asarray([x["ess_bulk"] for x in successful], dtype=float),
        ess_tail=np.asarray([x["ess_tail"] for x in successful], dtype=float),
        divergences=np.asarray([x["divergences"] for x in successful], dtype=np.int64),
    )
    return 0 if status == "PASS" else 4 if status == "FAIL" else 5


def main() -> int:
    parser = argparse.ArgumentParser(description="Resumable PyMC 6 SBC for Deadworlds cultural-transmission beta inference")
    parser.add_argument("--max-new", type=int, default=None, help="Run at most this many new simulations, then checkpoint and exit INCOMPLETE.")
    parser.add_argument("--reset", action="store_true", help="Discard an existing local checkpoint and start again from simulation 0.")
    args = parser.parse_args()

    import arviz_stats as azs

    doctor = pymc6_doctor(execute_smoke=True)
    _write_json(ROOT / "PYMC6_SBC_DOCTOR_REPORT.json", doctor)
    if not doctor.get("ok"):
        print(json.dumps(doctor, indent=2), flush=True)
        return 3

    d = POLICY["design"]
    nsim = int(d["simulations"])
    base_seed = int(d["random_seed"])
    lo = float(d["prior"]["lower"])
    hi = float(d["prior"]["upper"])
    sampling = d["pymc_sampling"]
    chains = int(sampling["chains"])
    draws = int(sampling["draws"])
    tune = int(sampling["tune"])
    source = np.asarray(d["conditioning_design"]["source_counts"], dtype=float)
    sizes = np.asarray(d["conditioning_design"]["destination_sample_sizes"], dtype=np.int64)

    rows = _load_resume_rows(nsim, base_seed, args.reset)
    start = len(rows)
    if start:
        print(f"Resuming frozen SBC v2 from simulation {start + 1}/{nsim}; {start} successful simulations already checkpointed.", flush=True)
    else:
        print(f"Starting frozen SBC v2: {nsim} simulations, {chains} chains x {draws} draws + {tune} tune, cores=1.", flush=True)
    if start >= nsim:
        print("All frozen simulations are already checkpointed; recomputing final report only.", flush=True)
        return _finalize(rows, doctor)

    new_limit = nsim if args.max_new is None else min(nsim, start + max(0, args.max_new))
    run_started = time.monotonic()
    for i in range(start, new_limit):
        sim_started = time.monotonic()
        generative_seed, sampling_seed = _expected_seeds(i, base_seed)
        print(f"--> simulation {i + 1}/{nsim} START (generative_seed={generative_seed}, sampling_seed={sampling_seed})", flush=True)
        rng = np.random.default_rng(generative_seed)
        beta_true = float(rng.uniform(lo, hi))
        destination = np.stack([
            rng.multinomial(int(n), transition_probabilities(src, beta_true))
            for src, n in zip(source, sizes)
        ]).astype(np.int64)
        try:
            _, idata = _fit_beta(
                source,
                destination,
                b_min=lo,
                b_max=hi,
                chains=chains,
                draws=draws,
                tune=tune,
                seed=sampling_seed,
            )
            beta = _posterior_values(idata, "beta").reshape(-1)
            rank = int(np.sum(beta < beta_true))
            u = float((rank + 0.5) / (beta.size + 1.0))
            q05, q10, q25, q75, q90, q95 = np.quantile(beta, [0.05, 0.10, 0.25, 0.75, 0.90, 0.95])
            c50 = bool(q25 <= beta_true <= q75)
            c80 = bool(q10 <= beta_true <= q90)
            c90 = bool(q05 <= beta_true <= q95)
            rhat = float(np.max(_diagnostic_values(azs.rhat(idata, var_names=["beta"]), "beta")))
            ess_bulk = float(np.min(_diagnostic_values(azs.ess(idata, var_names=["beta"], method="bulk"), "beta")))
            ess_tail = float(np.min(_diagnostic_values(azs.ess(idata, var_names=["beta"], method="tail"), "beta")))
            div = _sample_stats_values(idata, "diverging")
            divergences = int(np.asarray(div).sum()) if div is not None else -1
            row = {
                "simulation": i,
                "beta_true": beta_true,
                "generative_seed": generative_seed,
                "sampling_seed": sampling_seed,
                "rank": rank,
                "rank_u": u,
                "coverage_50": c50,
                "coverage_80": c80,
                "coverage_90": c90,
                "divergences": divergences,
                "rhat": rhat,
                "ess_bulk": ess_bulk,
                "ess_tail": ess_tail,
                "posterior_mean": float(np.mean(beta)),
                "posterior_sd": float(np.std(beta, ddof=1)),
                "status": "PASS_RUN",
            }
            rows.append(row)
            del idata
            elapsed = time.monotonic() - sim_started
            print(f"<-- simulation {i + 1}/{nsim} DONE | beta_true={beta_true:.4f} rhat={rhat:.4f} ess_bulk={ess_bulk:.1f} ess_tail={ess_tail:.1f} div={divergences} elapsed={elapsed:.1f}s", flush=True)
        except KeyboardInterrupt:
            print(f"Simulation {i + 1} interrupted. Completed simulations remain checkpointed; rerun to resume.", flush=True)
            _write_json(ROWS_PATH, rows)
            raise
        except Exception as exc:
            row = {
                "simulation": i,
                "beta_true": beta_true,
                "generative_seed": generative_seed,
                "sampling_seed": sampling_seed,
                "status": "FAILED_RUN",
                "error_type": type(exc).__name__,
                "error": str(exc)[:1000],
            }
            rows.append(row)
            elapsed = time.monotonic() - sim_started
            print(f"<-- simulation {i + 1}/{nsim} FAILED | {type(exc).__name__}: {str(exc)[:240]} | elapsed={elapsed:.1f}s", flush=True)
        _write_json(ROWS_PATH, rows)
        _write_json(PROGRESS_PATH, {
            "policy_version": POLICY["policy_version"],
            "completed_rows": len(rows),
            "successful_rows": sum(x.get("status") == "PASS_RUN" for x in rows),
            "failed_rows": sum(x.get("status") == "FAILED_RUN" for x in rows),
            "next_simulation": len(rows) + 1 if len(rows) < nsim else None,
            "elapsed_this_invocation_seconds": time.monotonic() - run_started,
        })
        gc.collect()

    if len(rows) < nsim:
        print(f"Checkpointed {len(rows)}/{nsim} simulations. Rerun the same command/notebook cell to continue from {len(rows) + 1}.", flush=True)
    return _finalize(rows, doctor)


if __name__ == "__main__":
    raise SystemExit(main())
