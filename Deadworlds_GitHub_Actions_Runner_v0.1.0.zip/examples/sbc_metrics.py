from __future__ import annotations

import math
from typing import Any

import numpy as np


def rank_metrics(rank_u: np.ndarray, coverages: dict[str, np.ndarray]) -> dict[str, Any]:
    u = np.asarray(rank_u, dtype=float)
    if u.ndim != 1 or u.size == 0 or np.any(~np.isfinite(u)) or np.any((u < 0) | (u > 1)):
        raise ValueError("rank_u must be a non-empty finite vector in [0,1]")
    ordered = np.sort(u)
    n = ordered.size
    upper = np.arange(1, n + 1, dtype=float) / n - ordered
    lower = ordered - np.arange(0, n, dtype=float) / n
    d = float(max(np.max(upper), np.max(lower)))
    return {
        "simulations": int(n),
        "rank_mean": float(np.mean(u)),
        "rank_variance": float(np.var(u, ddof=1)),
        "rank_ecdf_max_deviation": d,
        "coverage": {k: float(np.mean(np.asarray(v, dtype=bool))) for k, v in coverages.items()},
    }


def calibration_checks(metrics: dict[str, Any], policy: dict[str, Any]) -> dict[str, bool]:
    tol = policy["promotion_tolerances"]
    cov = metrics["coverage"]
    return {
        "rank_ecdf_dkw_pass": metrics["rank_ecdf_max_deviation"] <= tol["rank_ecdf_max_deviation"],
        "rank_mean_pass": abs(metrics["rank_mean"] - 0.5) <= tol["rank_mean_absolute_deviation_from_half_max"],
        "rank_variance_pass": abs(metrics["rank_variance"] - (1.0 / 12.0)) <= tol["rank_variance_absolute_difference_from_uniform_max"],
        "coverage_50_pass": abs(cov["50"] - 0.50) <= tol["coverage_50_absolute_error_max"],
        "coverage_80_pass": abs(cov["80"] - 0.80) <= tol["coverage_80_absolute_error_max"],
        "coverage_90_pass": abs(cov["90"] - 0.90) <= tol["coverage_90_absolute_error_max"],
    }


def dkw_bound(n: int, alpha: float) -> float:
    return math.sqrt(math.log(2.0 / alpha) / (2.0 * n))
