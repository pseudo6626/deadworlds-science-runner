from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from deadworlds_compute.plugins.cultural_common import transition_probabilities
from sbc_metrics import calibration_checks, dkw_bound, rank_metrics

ROOT = Path(__file__).resolve().parents[1]
POLICY = json.loads((ROOT / "SBC_POLICY.json").read_text(encoding="utf-8"))


def main() -> int:
    d = POLICY["design"]
    nsim = int(d["simulations"])
    seed = int(d["random_seed"])
    lo = float(d["prior"]["lower"])
    hi = float(d["prior"]["upper"])
    source = np.asarray(d["conditioning_design"]["source_counts"], dtype=np.int64)
    sizes = np.asarray(d["conditioning_design"]["destination_sample_sizes"], dtype=np.int64)
    grid = np.linspace(lo, hi, 2401, dtype=float)
    dx = float(grid[1] - grid[0])

    # Precompute log q(beta) for each fixed source transition. The multinomial
    # coefficient is constant in beta and cancels in posterior normalization.
    log_q = np.empty((source.shape[0], grid.size, source.shape[1]), dtype=float)
    for t, src in enumerate(source):
        p = src / src.sum()
        w = np.power(p[None, :], 1.0 - grid[:, None])
        q = w / w.sum(axis=1, keepdims=True)
        log_q[t] = np.log(q)

    rank_u = np.empty(nsim, dtype=float)
    covers = {"50": np.zeros(nsim, dtype=bool), "80": np.zeros(nsim, dtype=bool), "90": np.zeros(nsim, dtype=bool)}

    for i in range(nsim):
        gen_seed = (seed + 65537 * (i + 1)) & 0xFFFFFFFF
        rng = np.random.default_rng(gen_seed)
        beta_true = float(rng.uniform(lo, hi))
        destination = np.stack([
            rng.multinomial(int(n), transition_probabilities(src, beta_true))
            for src, n in zip(source, sizes)
        ])
        logp = np.einsum("ts,tgs->g", destination, log_q)
        logp -= np.max(logp)
        density = np.exp(logp)
        cdf = np.zeros_like(density)
        cdf[1:] = np.cumsum(0.5 * (density[:-1] + density[1:]) * dx)
        cdf /= cdf[-1]
        rank_u[i] = float(np.interp(beta_true, grid, cdf))
        for label, level in (("50", 0.50), ("80", 0.80), ("90", 0.90)):
            tail = (1.0 - level) / 2.0
            qlo = float(np.interp(tail, cdf, grid))
            qhi = float(np.interp(1.0 - tail, cdf, grid))
            covers[label][i] = qlo <= beta_true <= qhi

    metrics = rank_metrics(rank_u, covers)
    checks = calibration_checks(metrics, POLICY)
    report = {
        "policy_version": POLICY["policy_version"],
        "status": "PASS" if all(checks.values()) else "FAIL",
        "backend": "EXACT_GRID_SBC_DESIGN_PRECHECK_ONLY",
        "metrics": metrics,
        "checks": checks,
        "dkw": {
            "alpha": POLICY["promotion_tolerances"]["rank_ecdf_dkw_alpha"],
            "policy_bound": POLICY["promotion_tolerances"]["rank_ecdf_max_deviation"],
            "recomputed_bound": dkw_bound(nsim, POLICY["promotion_tolerances"]["rank_ecdf_dkw_alpha"]),
        },
        "interpretation": "Sanity check of the frozen SBC design using exact-grid inference. It is not the PyMC SBC gate and is not empirical model validation.",
    }
    out = ROOT / "EXACT_SBC_PRECHECK_REPORT.json"
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
