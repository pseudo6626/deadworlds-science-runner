from __future__ import annotations

import json
from pathlib import Path

from deadworlds_compute.contracts import JOB_SOURCE_RULE, JOB_VERSION, sha256_json

ROOT = Path(__file__).resolve().parent
ROWS = [
    ("P0", {"A": 50, "B": 30, "C": 20}),
    ("P1", {"A": 55, "B": 29, "C": 16}),
    ("P2", {"A": 60, "B": 27, "C": 13}),
    ("P3", {"A": 59, "B": 28, "C": 13}),
    ("P4", {"A": 72, "B": 17, "C": 11}),
    ("P5", {"A": 81, "B": 14, "C": 5}),
]
PARTITION = {
    "scheme": "K_FOLD_TRANSITIONS_V1",
    "fold_count": 3,
    "assignments": {"P0->P1": 0, "P1->P2": 1, "P2->P3": 2, "P3->P4": 0, "P4->P5": 1},
}


def package(plugin: str, artifact_format: str, inference: str) -> dict:
    input_data = {
        "trait_family": "synthetic_motif_class",
        "observation_unit": "find",
        "phase_order": [p for p, _ in ROWS],
        "phase_counts": [
            {"phase_id": p, "counts": counts, "sample_size": sum(counts.values())}
            for p, counts in ROWS
        ],
        "validation_partition": PARTITION,
        "source_semantics": "coded recovered-record frequency; not population prevalence",
    }
    params = {
        "chains": 4,
        "draws": 1000,
        "b_prior_min": -0.6,
        "b_prior_max": 0.6,
    }
    if plugin == "cultural_frequency_dependent_grid_v1":
        params["grid_points"] = 1201
    if plugin.startswith("pymc_"):
        params["tune"] = 1000
    plan = {
        "validation_unit_status": "DEFINED_AND_JUSTIFIED",
        "dependence_structure_status": "MODELED_OR_RESPECTED",
        "predeclared_discrepancies": ["mean_interphase_tv_distance", "mean_destination_shannon_entropy"],
        "heldout_or_cv_partition_status": "AVAILABLE",
        "sbc_status": "NOT_RUN",
        "prior_predictive_status": "NOT_RUN",
        "abc_summary_discrimination_status": "PARTIAL_STRONG_EFFECT_DISCRIMINATION_ONLY",
        "predictive_validation_method": "K_FOLD",
        "inference_method": inference,
        "evaluation_scope": "MODEL_ADEQUACY_AND_VALIDATED_RELATIVE_COMPARISON",
        "observed_variable": "phase_counts",
        "partition_sha256": sha256_json(PARTITION),
    }
    manifest = {
        "job_version": JOB_VERSION,
        "analysis_id": f"ct-local-pymc6-validation-{plugin}",
        "comparison_group_id": "ct:synthetic_motif_class",
        "candidate_model_id": "frequency_dependent_alternative",
        "source_module": "cultural_transmission",
        "source_version": "deadworlds-cultural-transmission-v1.0.0",
        "random_seed": 20261028,
        "model": {"plugin": plugin, "parameters": params},
        "input_data": input_data,
        "evaluation_plan": plan,
        "artifact_format": artifact_format,
    }
    return {
        "package_version": JOB_VERSION,
        "sourceRule": JOB_SOURCE_RULE,
        "manifest": manifest,
        "expected_hashes": {
            "job_manifest_sha256": sha256_json(manifest),
            "input_sha256": sha256_json(input_data),
            "model_spec_sha256": sha256_json(manifest["model"]),
            "evaluation_plan_sha256": sha256_json(plan),
        },
    }


def main() -> None:
    jobs = {
        "cultural_frequency_exact_validation_job.json": package(
            "cultural_frequency_dependent_grid_v1",
            "JSON_SUMMARY_WITH_EXTERNAL_DRAW_ARTIFACT",
            "GRID_BAYES",
        ),
        "cultural_frequency_pymc_validation_job.json": package(
            "pymc_cultural_frequency_dependent_v1",
            "ARVIZ_INFERENCE_DATA_NETCDF",
            "MCMC",
        ),
    }
    for name, data in jobs.items():
        path = ROOT / name
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(path)


if __name__ == "__main__":
    main()
