from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY = json.loads((ROOT / "VALIDATION_POLICY.json").read_text(encoding="utf-8"))


def _summary(raw: dict) -> dict:
    summaries = raw.get("parameter_summaries") or []
    beta = next((x for x in summaries if x.get("parameter_id") == "frequency_bias_beta"), None)
    if beta is None:
        raise ValueError("frequency_bias_beta summary missing")
    pv = raw.get("predictive_validation") or {}
    pointwise = [float(x["log_predictive_density"]) for x in pv.get("pointwise") or []]
    if len(pointwise) != 5:
        raise ValueError(f"expected five transition values; got {len(pointwise)}")
    diag = raw.get("sampler_diagnostics") or {}
    return {
        "elpd": float(pv["elpd"]),
        "se": float(pv["se"]),
        "pointwise": pointwise,
        "beta": {k: float(beta[k]) for k in ("mean", "sd", "q05", "q50", "q95")},
        "diagnostics": {
            "divergences": int(diag["divergences"]),
            "rhat_max": float(diag["rhat_max"]),
            "ess_bulk_min": float(diag["ess_bulk_min"]),
            "ess_tail_min": float(diag["ess_tail_min"]),
            "bfmi_min": None if diag.get("bfmi_min") is None else float(diag["bfmi_min"]),
        },
    }


def evaluate(raw: dict) -> dict:
    ref = POLICY["reference"]
    tol = POLICY["promotion_tolerances"]
    got = _summary(raw)
    diffs = {
        "elpd": abs(got["elpd"] - ref["elpd"]),
        "pointwise": [abs(a - b) for a, b in zip(got["pointwise"], ref["pointwise"])],
        "beta": {k: abs(got["beta"][k] - ref["beta"][k]) for k in ref["beta"]},
    }
    checks = {
        "all_values_finite": all(
            math.isfinite(x)
            for x in [
                got["elpd"], got["se"], *got["pointwise"], *got["beta"].values(),
                got["diagnostics"]["rhat_max"], got["diagnostics"]["ess_bulk_min"], got["diagnostics"]["ess_tail_min"],
            ]
        ),
        "elpd_within_tolerance": diffs["elpd"] <= tol["elpd_absolute_difference_max"],
        "all_pointwise_within_tolerance": max(diffs["pointwise"]) <= tol["pointwise_absolute_difference_max"],
        "beta_mean_within_tolerance": diffs["beta"]["mean"] <= tol["beta_mean_absolute_difference_max"],
        "beta_sd_within_tolerance": diffs["beta"]["sd"] <= tol["beta_sd_absolute_difference_max"],
        "beta_quantiles_within_tolerance": max(diffs["beta"][k] for k in ("q05", "q50", "q95")) <= tol["beta_quantile_absolute_difference_max"],
        "beta_sign_matches": got["beta"]["mean"] < 0 if tol["beta_mean_must_be_negative"] else True,
        "zero_divergences": got["diagnostics"]["divergences"] <= tol["divergences_max"],
        "rhat_pass": got["diagnostics"]["rhat_max"] <= tol["rhat_max"],
        "ess_bulk_pass": got["diagnostics"]["ess_bulk_min"] >= tol["ess_bulk_min"],
        "ess_tail_pass": got["diagnostics"]["ess_tail_min"] >= tol["ess_tail_min"],
    }
    return {
        "policy_version": POLICY["policy_version"],
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "observed": got,
        "absolute_differences": diffs,
        "tolerances": tol,
        "scientific_interpretation": POLICY["interpretation"],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("result_json")
    ap.add_argument("--out")
    args = ap.parse_args()
    raw = json.loads(Path(args.result_json).read_text(encoding="utf-8"))
    report = evaluate(raw)
    text = json.dumps(report, indent=2, ensure_ascii=False)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    return 0 if report["status"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
